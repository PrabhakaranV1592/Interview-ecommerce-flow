package com.interview.ex1.interview.dao;

import java.text.ParseException;

import com.interview.ex1.interview.model.OrderReq;
import com.interview.ex1.interview.model.Response;

public interface OrderDAO {
	Response add(OrderReq data) throws ParseException;
}
