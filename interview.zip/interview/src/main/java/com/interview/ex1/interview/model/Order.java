package com.interview.ex1.interview.model;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Document
@JsonInclude(Include.NON_NULL)
public class Order implements Serializable {

	private static final long serialVersionUID = -668173431043839360L;
	
	@Id
	private String id;
	private String itemId;
	private String accountId;
	private long orderQyt;
	private double perItemCost;
	private double totalPrice;
	private Date orderDate;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getItemId() {
		return itemId;
	}
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public long getOrderQyt() {
		return orderQyt;
	}
	public void setOrderQyt(long orderQyt) {
		this.orderQyt = orderQyt;
	}
	public double getPerItemCost() {
		return perItemCost;
	}
	public void setPerItemCost(double perItemCost) {
		this.perItemCost = perItemCost;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	
	public Order(String itemId, String accountId, long orderQyt, double perItemCost, double totalPrice,
			Date orderDate) {
		super();
		this.itemId = itemId;
		this.accountId = accountId;
		this.orderQyt = orderQyt;
		this.perItemCost = perItemCost;
		this.totalPrice = totalPrice;
		this.orderDate = orderDate;
	}
	public Date getOrderDate() {
		return orderDate;
	}

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+5:30")
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Orders [id=" + id + ", itemId=" + itemId + ", accountId=" + accountId + ", orderQyt=" + orderQyt
				+ ", perItemCost=" + perItemCost + ", totalPrice=" + totalPrice + "]";
	}
	
	
	
	
	

}
