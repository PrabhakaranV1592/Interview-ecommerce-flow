package com.interview.ex1.interview.model;

public class Response {

	private int statusCode;
	private String message;
	private String status;
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Response(int statusCode, String message, String status) {
		super();
		this.statusCode = statusCode;
		this.message = message;
		this.status = status;
	}
	public Response(String status) {
		super();
		this.status = status;
	}
	public Response(String message, String status) {
		super();
		this.message = message;
		this.status = status;
	}
	public Response(int statusCode, String message) {
		super();
		this.statusCode = statusCode;
		this.message = message;
	}
	public Response(int statusCode) {
		super();
		this.statusCode = statusCode;
	}
	public Response() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
