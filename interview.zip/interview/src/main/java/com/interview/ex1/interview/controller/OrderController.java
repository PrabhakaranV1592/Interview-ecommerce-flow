package com.interview.ex1.interview.controller;

import java.text.ParseException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.http.MediaType;
import com.interview.ex1.interview.model.OrderReq;
import com.interview.ex1.interview.model.Response;
import com.interview.ex1.interview.repos.OrderRepo;

@RestController
public class OrderController {
	
	@Autowired
	private OrderRepo orderRepo;
	
	//API to Make an order
	@PostMapping(path = "/order", consumes = MediaType.APPLICATION_JSON_VALUE)
	public Response add(@RequestBody OrderReq data) {
		Response res = null;
		try {
			res = orderRepo.add(data);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return res;
	}

}
