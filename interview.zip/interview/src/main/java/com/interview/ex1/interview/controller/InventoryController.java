package com.interview.ex1.interview.controller;

import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.interview.ex1.interview.model.Inventory;
import com.interview.ex1.interview.repos.InventoryRepo;

@RestController
public class InventoryController {
	@Autowired
	private InventoryRepo inventoryRepo;
	@GetMapping(path = "/getInventoryList", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Inventory>> getInventoryList() throws ParseException {
		return new ResponseEntity<List<Inventory>>(inventoryRepo.getInventoryList(), HttpStatus.OK);
	}
}
