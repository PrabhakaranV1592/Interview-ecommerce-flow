package com.interview.ex1.interview.model;

public class OrderReq {
	private String itemId;
	private String accountId;
	private long orderQyt;
	
	public String getItemId() {
		return itemId;
	}
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public long getOrderQyt() {
		return orderQyt;
	}
	public void setOrderQyt(long orderQyt) {
		this.orderQyt = orderQyt;
	}
	public OrderReq(String itemId, String accountId, long orderQyt) {
		super();
		this.itemId = itemId;
		this.accountId = accountId;
		this.orderQyt = orderQyt;
	}
	public OrderReq() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "OrderReq [itemId=" + itemId + ", accountId=" + accountId + ", orderQyt=" + orderQyt + "]";
	}
	
	
}
