package com.interview.ex1.interview.controller;

import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.interview.ex1.interview.model.Account;
import com.interview.ex1.interview.model.Order;
import com.interview.ex1.interview.repos.AccountRepo;

@RestController
public class AccountController {

	@Autowired
	private AccountRepo accountRepo;
	
	// API to get List of Order made by a user
	@GetMapping(path = "/getOrderList", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Order>> getOrderList(@RequestParam String accountId) throws ParseException {
		return new ResponseEntity<List<Order>>(accountRepo.getOrderList(accountId), HttpStatus.OK);
	}
	
	//API to get list of User Accounts
	@GetMapping(path = "/getAccountList", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Account>> getAccountList() throws ParseException {
		return new ResponseEntity<List<Account>>(accountRepo.getAccountList(), HttpStatus.OK);
	}
}
