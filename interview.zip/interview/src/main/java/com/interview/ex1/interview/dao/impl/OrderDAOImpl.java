package com.interview.ex1.interview.dao.impl;

import java.text.ParseException;
import java.util.Date;

import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;

import com.interview.ex1.interview.dao.OrderDAO;
import com.interview.ex1.interview.model.Account;
import com.interview.ex1.interview.model.Inventory;
import com.interview.ex1.interview.model.Order;
import com.interview.ex1.interview.model.OrderReq;
import com.interview.ex1.interview.model.Response;

@Component
public class OrderDAOImpl implements OrderDAO {
	
	@Autowired
	private MongoTemplate mongoTemplate;

	@Override
	public Response add(OrderReq data) throws ParseException {
		try {
			// TODO Auto-generated method stub
			//code 1 = success; code 2 = insuffcentParams; code 3 = OrderNotPossible;code 5 = internalError;  
		
			if (data == null) {// handling when no data sent
				return new Response(2, "Error; No Data Provided", "NoData");
			} else if (Strings.isEmpty(data.getAccountId())) {// handling when Account Id data  not sent
				return new Response(2, "Error; Account Id Required", "InsufficentData");
			} else if (Strings.isEmpty(data.getItemId())) {// handling when item Id data  not sent
				return new Response(2, "Error; Item Id Required", "InsufficentData");
			} else if (data.getOrderQyt() <= 0) {// handling when Correct Quantity not sent
				return new Response(2, "Error; Quantity Need to be more then 0", "InsufficentData");
			} else if (!mongoTemplate.exists(Query.query(Criteria.where("id")
					.is(data.getAccountId())), Account.class)) {// handling Check for Account present
				return new Response(2, "Error; Invalid Account Id", "InvaildData");
			} else if (!mongoTemplate.exists(Query.query(Criteria.where("id")
					.is(data.getItemId())), Inventory.class)) {// handling Check for Item present
				return new Response(2, "Error; Invalid Item Id", "InvaildData");
			}
			//Fetching inventory item data using itemId
			Inventory inventory = mongoTemplate.findOne(Query.query(Criteria.where("id").is(data.getItemId())),
					Inventory.class);
			if (inventory.getItemQuantity() == 0 
					|| inventory.getItemQuantity() < data.getOrderQyt()) {//check to see if Qunatity of the item present
				
				return new Response(2, "Error; Insufficent Quantity In Inventory", "InsufficentQty");
			}
			//Fetching Account data using AccountId
			Account accounts = mongoTemplate.findOne(Query.query(Criteria.where("id").is(data.getAccountId())),
					Account.class);
			//Creating new class object for the order
			Order order = new Order();
			order.setOrderDate(new Date());
			order.setAccountId(accounts.getId());
			order.setItemId(inventory.getId());
			order.setOrderQyt(data.getOrderQyt());
			order.setPerItemCost(inventory.getPerItemCost());
			order.setTotalPrice((inventory.getPerItemCost() * data.getOrderQyt()));
			mongoTemplate.save(order); // Saving the Order
			long newQlty = inventory.getItemQuantity() - data.getOrderQyt(); // updating the quantity for the item
			mongoTemplate.updateFirst(Query.query(Criteria.where("id").is(data.getItemId())),
					new Update().set("itemQuantity", (newQlty < 0 ? 0 : newQlty)), Inventory.class);
			return new Response(1, "Success; Item Order Placed Successfully", "Saved"); // returning the status
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new Response(5, "Error; Internal Server Error: " + e.getMessage(), "InternalServerError"); // sending server error info 
		}
	}
}
