package com.interview.ex1.interview.dao;

import java.util.List;

import com.interview.ex1.interview.model.Account;
import com.interview.ex1.interview.model.Order;
import com.interview.ex1.interview.model.Response;

public interface AccountDAO {
	Response add(Account acc);
	List<Order> getOrderList(String accountId);
	List<Account> getAccountList();
}
