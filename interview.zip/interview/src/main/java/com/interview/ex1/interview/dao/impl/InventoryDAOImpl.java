package com.interview.ex1.interview.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Component;

import com.interview.ex1.interview.dao.InventoryDAO;
import com.interview.ex1.interview.model.Inventory;
import com.interview.ex1.interview.model.Response;

@Component
public class InventoryDAOImpl implements InventoryDAO {

	@Autowired
	private MongoTemplate mongoTemplate;
	@Override
	public Response add(Inventory acc) {
		// TODO Auto-generated method stub creation of Inventory record
		return null;
	}
	
	@Override
	public List<Inventory> getInventoryList() {
		// TODO Auto-generated method stub
		return mongoTemplate.findAll(Inventory.class);
	}
}
