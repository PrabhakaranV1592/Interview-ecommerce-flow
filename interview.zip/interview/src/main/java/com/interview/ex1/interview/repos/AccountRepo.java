package com.interview.ex1.interview.repos;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.interview.ex1.interview.dao.AccountDAO;
import com.interview.ex1.interview.model.Account;

@Repository
public interface AccountRepo extends MongoRepository<Account, String>, AccountDAO{

}
