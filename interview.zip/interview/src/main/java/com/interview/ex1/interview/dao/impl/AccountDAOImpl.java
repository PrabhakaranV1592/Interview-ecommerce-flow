package com.interview.ex1.interview.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import com.interview.ex1.interview.dao.AccountDAO;
import com.interview.ex1.interview.model.Account;
import com.interview.ex1.interview.model.Order;
import com.interview.ex1.interview.model.Response;

@Component
public class AccountDAOImpl implements AccountDAO {
	
	@Autowired
	private MongoTemplate mongoTemplate;

	@Override
	public Response add(Account acc) {
		// TODO Auto-generated method stub for Creation of User
		return null;
	}
	
	@Override
	public List<Order> getOrderList(String accountId) {
		// TODO Auto-generated method stub
		return mongoTemplate.find(Query.query(Criteria.where("accountId").is(accountId)), Order.class);
	}
	
	@Override
	public List<Account> getAccountList() {
		// TODO Auto-generated method stub
		return mongoTemplate.findAll(Account.class);
	}
}
