package com.interview.ex1.interview.dao;

import java.util.List;

import com.interview.ex1.interview.model.Inventory;
import com.interview.ex1.interview.model.Response;

public interface InventoryDAO {
	Response add(Inventory acc);
	List<Inventory> getInventoryList();
}
