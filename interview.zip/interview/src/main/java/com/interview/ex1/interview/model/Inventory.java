package com.interview.ex1.interview.model;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Document
@JsonInclude(Include.NON_NULL)
public class Inventory implements Serializable {

	private static final long serialVersionUID = -668173431044539360L;
	
	@Id
	private String id;
	private String itemName;
	private long itemQuantity;
	private double perItemCost;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public long getItemQuantity() {
		return itemQuantity;
	}
	public void setItemQuantity(long itemQuantity) {
		this.itemQuantity = itemQuantity;
	}
	public double getPerItemCost() {
		return perItemCost;
	}
	public void setPerItemCost(double perItemCost) {
		this.perItemCost = perItemCost;
	}
	public Inventory(String itemName, long itemQuantity, double perItemCost) {
		super();
		this.itemName = itemName;
		this.itemQuantity = itemQuantity;
		this.perItemCost = perItemCost;
	}
	public Inventory() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Inventory [id=" + id + ", itemName=" + itemName + ", itemQuantity="
				+ itemQuantity + ", perItemCost=" + perItemCost + "]";
	}
	
	
}
